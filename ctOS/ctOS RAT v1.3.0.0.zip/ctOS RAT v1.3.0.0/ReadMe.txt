For a localhost test:
Use these settings: 127.0.0.1 port 1337
Request Start with Admin
Hide Server
Disable the 6 Anti's
Elevate to Admin after Execution

Then run on Sandboxie
If you get flickering, terminate all programs, then delete usersdat.exe from MY Documents and re-run rat on Sandboxie.


The functions like CryptoMiner, RemoteProxy, ReverseProxy, UPnP require actual internet connection and won't run on localhost.


Notes:
1. Do not run ctOS.exe (builder) as admin
2. Stub can be random as admin (gives you more privileges) or as normal user (limits functions).
