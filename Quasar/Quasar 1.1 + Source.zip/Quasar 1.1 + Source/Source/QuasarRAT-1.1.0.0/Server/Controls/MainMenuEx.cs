﻿using System.Windows.Forms;

namespace xServer.Controls
{
    internal class MainMenuEx : MainMenu
    {
        public MainMenuEx()
        {
        }
    }
}