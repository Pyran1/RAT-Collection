﻿namespace xServer.Core.Data
{
    public static class AutostartItem
    {
        public static string Name { get; set; }
        public static string Path { get; set; }
        public static int Type { get; set; }
    }
}
