Password for using this software is 

"public1"

hf ...
and if ya advanced in hacking cracking modding or anithing else yy think it could be needed in a crew like our 
write a mail @ 

haccrew@pop3.ru 


greetZ
haZl0oh

HAC CreW 2007
[HaZl0oh] 