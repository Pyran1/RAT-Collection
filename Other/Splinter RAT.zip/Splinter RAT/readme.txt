Aardvark is a dropper/downloader module created to update Splinter RAT if required.  More on this to come in the future...

Thanks!

-Solomon