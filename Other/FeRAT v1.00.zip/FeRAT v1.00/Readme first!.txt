 ++++++++++++++
+ FeRAT v1.00  +
 ++++++++++++++

29th May 2003

MAIN
----

Coded by triforce (Fearless crew)
Coding help from: Read101, tataye and Faceless Wonder

NOTES
-----

Here is the final release for v1.00. Its taken a long time to release but its not easy coding a rat and doing a degree at uni :-) Hope you enjoy this, and if any bugs are found please email me (triforce@areyoufearless.com) or visit the forums. I didnt have the time to add all the features I would have liked but I will save them for future versions... Please take time to read through the help files before using FeRAT.


CONTACT
-------

http://areyoufearless.com
triforce@areyoufearless.com

Support my good friend Gobo! http://www.freegobo.com/
