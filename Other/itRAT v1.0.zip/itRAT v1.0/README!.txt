-------------------------------------------
-------------------itRAT-------------------
-------------------------------------------


- itRAT is the CLIENT
- Stub is the stub :))


There , you have an Extension Spoofer coded by DarkCoder and a QIcon CHanger , modified by DarkCoder.


SPECIAL THANKS TO :

---
-sandabot
-DarkCoder
-Romanian Security Team
---



I'M SORRY BUT THE DDOS FUNCTION DOESN'T WORK .. I'M WORKING AT IT.







|||||||||||||||| www.rstforums.com |||||||||||||||||
|||||||||||||||| www.rstforums.com |||||||||||||||||
|||||||||||||||| www.rstforums.com |||||||||||||||||

--------- Coded by DizZy (tudor13mn13) ---------

