###############################
	XPloit Readme
###############################
by My-Self

www.selfsoft.de.be

-----------

1) Short introduction
2) Quickstart
3) Features
4) Version history
4) Contact

------------


1) Short Introduction

Xploit is an advanced remote adminstration tool, wich is able
to get trough the most hardware/software firewalls. You will be able to
completely control an unlimited number of connected computers, that you own.

2) Quick start

- Open the Client
- Click create server
- Connect IP/DNS: Enter YOUR Ip or dns, for example 127.0.0.1 or lala.dyndns.org
- Filename when installed: make shure it ends with .exe or the Server wont work
- Port (Main): the Main-Port for the connection (Commands, directories..., change the Client port to this port or the 	       connection won't work)
- Port (Filetransfer): The port for Filetransfers
- Dll Filename: the .dll that includes the server Code, make shure it ends with .dll
- Injection: You can inject your code in a specified path or the standard application
	     for an extension (firewall bypass), for example "html", the server is injected to iexplore.exe 
	     or firefox.exe
- Melt Server: Deletes the clicked server (not the installed one)
- startup message: lets you create a messagebox on startup of the server
- Add Kbytes: add a specific number of bytes at the end of the server.0
- click "Build"
- Once you createt the server, run it on the Computer you like to control
- a message should appear in Xploit and an list entry with the name, ip,... of the remote pc should appear.
- now you have full control over this computer, click right mouse to open the menu.
- finished :)

3) Features

Xploit has a lot of features, the most important here:

Xploit Features:

+ Server
- Reverse connection
- process injection
- Firewall bypass
- Registry/Run
- ActiveX Startup
+ Full Filemanager
+ Screencapture
- Simulate Keyboard
- Simulate Mouse
- Screenshots are Compressed with JPEG and JCalG1-Algorythm for extra-fast transfer
+ Process Manager
- Kill process
+ Administrator
- Disable Keyboard & Mouse
- Disable Taskmanager
- Disable Monitor
- Get & Set Clipboard text
+ Fun (Lame ;)
- Desktop-Paint
- Beep
- Open/Close CD-Tray
- Swap Mousebuttons
- Draw text on screen
- Send to URL
- Taskbar access (Open startmenu, minimize windows, ...)
+ Clientinfo
+ PC
- Shutdown
- Log off
- Restart
- Quickrestart (Computer restarts imediately)
+ Keylogger
+ Full Registry access
+ Chat
+ Remote Shell (Windows console)
+ Full Window manager
- Minimize, Maximize, Close, Kill Windows
- Block / Unblock Window Input
- Set Windowtitle
- Send keys to Windows
+ Plugin Console

4) Contact

Web: http://web9.h57331.serverkompetenz.net/myself/hp/
ICQ: 234-989-169
E-Mail: NJoe@gmx.net
IRC: irc.quakenet.org - #pizzano