<?php
//*****************************************
// Author: icyinferno
// E-mail: 1cy1nferno109@gmail.com
// Copyright �2009, IcyInferno Productions 
//*****************************************
   define('web_username',   'icyinferno');		// Username for logviewer (index.php)
   define('web_password',   'password');		// Password for logviewer (index.php)
   define('web_dbHost',     "localhost");   	// MySQL host
   define('web_dbDatabase', 'remotepenDB');		// MySQL database name
   define('web_dbUser',     'sqluser');			// MySQL username
   define('web_dbPass',     'sqlpass');			// MySQL password
 ?>
