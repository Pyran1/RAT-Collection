========================
 Author      : icyinferno
 E-mail	     : 1cy1nferno109@gmail.com
 Terms of use: IN ORDER TO USE THE PROGRAM, YOU MUST READ AND AGREE WITH DISCLAIMER.TXT.
========================

========================
 Information: 2.2 Released: 16.8.2009
========================
   [+] New Features:
	[+] All PHP problems have been fixed + a new theme has been implemented!
	[+] Updated Firefox Recovery
	[+] Added Internet Download Manager Recovery
	[+] Added Yahoo Messenger 8.x,9.x Recovery
	[+] Builders dark theme removed

   [+] Recovery:
	[+] Trillian
	[+] Pidgin and Gaim
	[+] PaltalkScene
	[+] Digsby 
	[+] Live Messenger
	[+] MSN Messenger
	[+] Yahoo Messenger 8.x,9.x (NEW)
	[+] AIM 6.xx (Private Version only)
	[+] Miranda  (Private Version only)
	[+] Google Talk (Private Version only) 
	[+] Firefox 2.xx - 3.xx (Updated - NEW)
	[+] IE6
	[+] IE7 - 8
	[+] Internet Download Manager Recovery (NEW)
	[+] Filezilla
	[+] Smart FTP
	[+] FlashFXP
	[+] CoreFTP
	[+] NO-IP
	[+] DynDNS 
	[+] Outlook
	[+] CamFrog 
	[+] Custom CD-Key Grabber (Input own path to key you want to grab) (On the Public version you may only input one path, private version has no set limit which means you can steal as many keys as you want)

   [+] Icon Options:
   	[+] Replace Default Icon:
	[+] Icon Hunter 

   [+] Main Features
	[+] FUD Scantime + Runtime
		[+] All strings are encrypted
		[+] All your inputted data, (PHP url, settings, etc) are encrypted.
		[+] All API's that can be encrypted/called dynamically are encrypted.
	[+] No 3rd party applications used, all functions are programmed by me.
	[+] Send info via PHP
	[+] Output requires NO dependencies. (Builder does though)
	[+] Pick the dropped files attributes
		[+] Hidden
		[+] Read only
		[+] System
	[+] Ability to import FUD stubs
	[+] Anti-Generic Sandbox
	[+] Anti-Virtual PC, VMWare, VirtualBox 
	[+] Instalation options
		[+] You get the option to pick where the file drops to / where in the registry to add the startup key.

   [+] Other Features 
	[+] Option to compress with UPX
	[+] Scramble the UPX header 
	[+] File Version Info Cloner
	[+] Fake error message 
	[+] Change the Date of the outputted executable's date
	[+] Increase the files size
		[+] Add NOP bytes to the file
	[+] Log Decryption utility included in builder
	[+] Load and Save your sessions!

   [+] Private Version  
	[+] All of the listed features above + a unique stub that no one else has.
	[+] AIM 6.xx recovery
	[+] Miranda recovery
	[+] Google Talk recovery
	[+] Melt 
	[+] Option on builder to delete, output.exe, icon. (save kbs)
	[+] No set number of CD-Key Paths (You can add as many keys as you want grabbed)
	
	Contact me if interested in private version.
	
	Prices;
	$25 for unique FUD copy of the public version of Remote Penetration 1.60 (FTP/SMTP support)
	$30 for unique FUD copy of the public version of Remote Penetration 2.1 (Current version, PHP support)
	$50 for unique FUD copy of the private version of Remote Penetration 1.60 (FTP/SMTP support)
	$75 for unique FUD copy of the private version of Remote Penetration 2.1 (Current version, PHP support)
	