PHP Notify Script Readme :
--------------------------------------
Upload the file "index.php" and "ip.html" to
an free webspace account which supports php ! 
Link the "index.php" file's webadress in server
configuration!
In client you have to link the webadress of "ip.html" in Server Listwindow !

HAVE PHUN !  