Aqua (Remote Administration Kit) 0.2 - http://sourceforge.net/projects/mmap
===========================================================================

1.Introduction
--------------
0.2 is almost a complete rewrite of 0.1, this is the reason that it took so
long to get this version out. A rewrite was necessary to get things like
file transfer working. The Winsock API wrapperwas full of bugs in version 
0.1 so this has been rehashed.
0.2 sees the introduction of ServerEdit which is a major step in creating
a sucessful remote admin tool.


