0nly1 RAT DEMO version 1.92
- just a buggy version current version is 1.98 and is fully Wk3 compatible (this isnt)

!!! DEMO VERSION FOR TESTING PURPOSES ONLY !!!

Demo version - server is preconfigured and you have no possibility to reconfigure it!

*tips:
- dont forget to try internal servers FTP server on port 21 (demo settings), please use Total Commander as FTP server and when
  connected dont forget to try HELP and DIR commands!
- internal settings cannot be changed :)
- in this demo version is no global notification, so dont worry, you can test howerver you want, noone will be notified except you (see setting below -
  SIN notify to 127.0.0.1)
- UDP notification works only for 127.0.0.1 host (demo version)
- process and files hiding works (not on 2k3 - this is fixed in new fully version)
- dont forget - FTP server's not anonymous, user and password are: user, password :)  -  demo presets...

- on 2k3 is not working remove server, after remove you must kill "trojan.exe" process in taskmanager and everything will be removed... [fixed in fully v.1.98]

Internal settings in server:

- Melting: YES
- VictimName: Victim
- FileName: trojan.exe
- FileResideDir: %WINDIR

- ServerSocketPort: 123
- UDP_Notify: YES
- UDP_Port: 124
- HTTPProxy_Port: 125
- FTP_Port: 21
- FTP username: user
- FTP password: password

- SIN_Notify: YES
- SIN_IP: 127.0.0.1
- SIN_Port: 122

- ServerPriorityClass: High
- StartupMethod: 2
- KName: MsHostDlls
- ActiveX: {08B0E5C0-4FCB-11CF-AAA5-00823C913200}

- AutoDisableXPFirewall: NO
- AllowXPTaskManager: YES
- LockCDsOnStart: ''

- UIN: ''
- ICQPagerNotification: NO
- AutorunRegistryAddKey: YES
- EmailNotification: NO
- ReallyForceExitWindows: YES
- KillFirewalls: NO

- UninstallKB: NO
- ServerPassword: ''
- ScriptNotification: NO
- RootKit: DISABLED
- FakeMsg_Enabled: YES
- FakeMsg_lpText: Warning!
- FakeMsg_lpCaption: Warning a demonstration version of old'#13'0nly1 RAT is executed on your computer !!!
- FakeMsg_Process: RANDOM_PARENT_DEFAULT


Best regards,
Rm.
