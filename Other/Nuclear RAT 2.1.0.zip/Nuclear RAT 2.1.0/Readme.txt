       Nuclear RAT 2.1.0 
        by caesar2k
====================================
Files that should be inside the zip:
- changelog.txt
- Readme.txt
- change.php
- logger.php
- client.exe
- client.dklang
=====================================
Download from the author website:
The precedence of this program can 
only be assured if you got it from 
www.nuclearwintercrew.com
=====================================
Disclaimer:
This program is made for legit use.
Nuclear RAT is provided as-is without 
any express or implied warranty in  no 
event will the author be held liable or 
responsible for any illegal action[s] or 
damage[s] arising from the use of it. 
Use Nuclear RAT at your own risk. If you 
do anything illegal with this program you
are the only one responsible for it.
=====================================
Plugins, tutorial or language files:
Check the website for either language files,
plugins, or a tutorial for Nuclear RAT.
You may translate Nuclear RAT using the
DKLang Translator Software, loading
the "client.dklang" file. If you want
me to put any plugins, tutorials or
language files on the NWC website,
use the contact page on the site to
email me.
=====================================
Important notes about client functionality:
To get a quick help about some function, 
click the "?" sign next to it to show
the help. The best fonts for the client are
Tahoma and Arial Unicode MS (the later have
support for ALL languages)
All windows in the client have two hotkeys,
ESC and F1. When you press F1, the current
focused client window (let's say, File Manager)
will become hidden, that can be shown again
clicking in the "Opened windows" part.
When you press ESC, the current focused
window will be closed (and any information
that was previously displayed is lost)
=====================================
Bug reporting, suggestion, critics:
Visit the forums or email me (information
on the website)
=====================================
Thanks to the people that made it possible:
Aphex, stm, drocon, akcom, s13az3, 
Andr�, Princeali, sphinx, Positron, 
Team Nexgen, satan_addicted, LOM, 
Heike, x140d4n, Lucifer0000, i2av,
Crazy Boris, X_DEVIOUZ_DISEEZ_X, Eagle
and the people that helped the testing!

Also thanks to all the translators for
the hard work with the translation of
this program! 
=====================================
       Nuclear Winter Crew 2007
      [www.nuclearwintercrew.com]