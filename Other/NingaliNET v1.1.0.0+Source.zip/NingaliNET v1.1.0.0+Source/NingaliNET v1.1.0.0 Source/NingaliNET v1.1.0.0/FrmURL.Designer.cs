﻿namespace NINGALINET
{
	// Token: 0x02000028 RID: 40
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class FrmURL : global::System.Windows.Forms.Form
	{
		// Token: 0x0600079C RID: 1948 RVA: 0x0003CFB4 File Offset: 0x0003B1B4
		[global::System.Diagnostics.DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && this.components != null)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x0600079D RID: 1949 RVA: 0x0003CFF8 File Offset: 0x0003B1F8
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Label1 = new global::System.Windows.Forms.Label();
			this.Label2 = new global::System.Windows.Forms.Label();
			this.TextBox1 = new global::System.Windows.Forms.TextBox();
			this.TextBox2 = new global::System.Windows.Forms.TextBox();
			this.Button1 = new global::System.Windows.Forms.Button();
			this.Button2 = new global::System.Windows.Forms.Button();
			this.SuspendLayout();
			this.Label1.AutoSize = true;
			global::System.Windows.Forms.Control arg_65_0 = this.Label1;
			global::System.Drawing.Point location = new global::System.Drawing.Point(14, 4);
			arg_65_0.Location = location;
			this.Label1.Name = "Label1";
			global::System.Windows.Forms.Control arg_8C_0 = this.Label1;
			global::System.Drawing.Size size = new global::System.Drawing.Size(31, 14);
			arg_8C_0.Size = size;
			this.Label1.TabIndex = 0;
			this.Label1.Text = "Link";
			this.Label2.AutoSize = true;
			global::System.Windows.Forms.Control arg_CB_0 = this.Label2;
			location = new global::System.Drawing.Point(14, 53);
			arg_CB_0.Location = location;
			this.Label2.Name = "Label2";
			global::System.Windows.Forms.Control arg_F2_0 = this.Label2;
			size = new global::System.Drawing.Size(46, 14);
			arg_F2_0.Size = size;
			this.Label2.TabIndex = 1;
			this.Label2.Text = "Run As";
			this.TextBox1.BackColor = global::System.Drawing.Color.FromArgb(40, 40, 40);
			this.TextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TextBox1.ForeColor = global::System.Drawing.Color.LimeGreen;
			global::System.Windows.Forms.Control arg_157_0 = this.TextBox1;
			location = new global::System.Drawing.Point(14, 22);
			arg_157_0.Location = location;
			this.TextBox1.Name = "TextBox1";
			global::System.Windows.Forms.Control arg_181_0 = this.TextBox1;
			size = new global::System.Drawing.Size(420, 20);
			arg_181_0.Size = size;
			this.TextBox1.TabIndex = 2;
			this.TextBox2.BackColor = global::System.Drawing.Color.FromArgb(40, 40, 40);
			this.TextBox2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TextBox2.ForeColor = global::System.Drawing.Color.LimeGreen;
			global::System.Windows.Forms.Control arg_1D6_0 = this.TextBox2;
			location = new global::System.Drawing.Point(14, 70);
			arg_1D6_0.Location = location;
			this.TextBox2.Name = "TextBox2";
			global::System.Windows.Forms.Control arg_200_0 = this.TextBox2;
			size = new global::System.Drawing.Size(231, 20);
			arg_200_0.Size = size;
			this.TextBox2.TabIndex = 3;
			this.Button1.BackColor = global::System.Drawing.Color.FromArgb(20, 20, 20);
			this.Button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			global::System.Windows.Forms.Control arg_248_0 = this.Button1;
			location = new global::System.Drawing.Point(252, 69);
			arg_248_0.Location = location;
			this.Button1.Name = "Button1";
			global::System.Windows.Forms.Control arg_26F_0 = this.Button1;
			size = new global::System.Drawing.Size(87, 25);
			arg_26F_0.Size = size;
			this.Button1.TabIndex = 4;
			this.Button1.Text = "Run";
			this.Button1.UseVisualStyleBackColor = false;
			this.Button2.BackColor = global::System.Drawing.Color.FromArgb(20, 20, 20);
			this.Button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			global::System.Windows.Forms.Control arg_2D3_0 = this.Button2;
			location = new global::System.Drawing.Point(346, 69);
			arg_2D3_0.Location = location;
			this.Button2.Name = "Button2";
			global::System.Windows.Forms.Control arg_2FA_0 = this.Button2;
			size = new global::System.Drawing.Size(87, 25);
			arg_2FA_0.Size = size;
			this.Button2.TabIndex = 5;
			this.Button2.Text = "Cancel";
			this.Button2.UseVisualStyleBackColor = false;
			global::System.Drawing.SizeF autoScaleDimensions = new global::System.Drawing.SizeF(7f, 14f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Black;
			size = new global::System.Drawing.Size(443, 354);
			this.ClientSize = size;
			this.Controls.Add(this.Button2);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.TextBox2);
			this.Controls.Add(this.TextBox1);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.Label1);
			this.Font = new global::System.Drawing.Font("Arial", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.Name = "FURL";
			this.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FURL";
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x0400038B RID: 907
		private global::System.ComponentModel.IContainer components;
	}
}
