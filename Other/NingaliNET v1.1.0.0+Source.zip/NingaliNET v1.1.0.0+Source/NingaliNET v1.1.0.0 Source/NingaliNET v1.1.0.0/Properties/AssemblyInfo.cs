﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("Remote Administration Tools")]
[assembly: AssemblyCopyright("Copyright ©  2016 im523")]
[assembly: Guid("4f6fd792-8a6b-4489-8aba-eaf5d0677d4d")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]
[assembly: ComVisible(false)]
[assembly: CompilationRelaxations(8)]
[assembly: AssemblyProduct("NingaliNET v1.1.0.0")]
[assembly: AssemblyTitle("NingaliNET v1.1.0.0")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
