﻿using System;

// Token: 0x02000002 RID: 2
internal static class Class0
{
}
