﻿namespace NINGALINET
{
	// Token: 0x02000013 RID: 19
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class FrmFilemanager : global::System.Windows.Forms.Form
	{
		// Token: 0x060003AE RID: 942 RVA: 0x00023670 File Offset: 0x00021870
		[global::System.Diagnostics.DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && this.components != null)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060003AF RID: 943 RVA: 0x000236B4 File Offset: 0x000218B4
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::NINGALINET.FrmFilemanager));
			this.StatusStrip1 = new global::System.Windows.Forms.StatusStrip();
			this.SL = new global::System.Windows.Forms.ToolStripStatusLabel();
			this.ContextMenuStrip1 = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.RefreshToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ContextMenuStrip2 = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.UPToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RunToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RefreshToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripSeparator1 = new global::System.Windows.Forms.ToolStripSeparator();
			this.DeleteToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RenameToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripSeparator4 = new global::System.Windows.Forms.ToolStripSeparator();
			this.RarToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.UnrarToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.UploadToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.DownloadToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.CorruptToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.StripToolStripMenuItem = new global::System.Windows.Forms.ToolStripSeparator();
			this.EditToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.HiddenToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ShowToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.HiddenToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripSeparator3 = new global::System.Windows.Forms.ToolStripSeparator();
			this.CutToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.CopyToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.PastToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripSeparator2 = new global::System.Windows.Forms.ToolStripSeparator();
			this.NewFolderToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.NewFolderToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.NewEmptyFileToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripSeparator5 = new global::System.Windows.Forms.ToolStripSeparator();
			this.OpenFolderToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ColumnHeader5 = new global::System.Windows.Forms.ColumnHeader();
			this.TextBox1 = new global::System.Windows.Forms.TextBox();
			this.Timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.PictureBox2 = new global::System.Windows.Forms.PictureBox();
			this.PictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.Panel1 = new global::System.Windows.Forms.Panel();
			this.ToolStrip1 = new global::System.Windows.Forms.ToolStrip();
			this.ToolStripButton2 = new global::System.Windows.Forms.ToolStripButton();
			this.ToolStripButton3 = new global::System.Windows.Forms.ToolStripButton();
			this.ToolStripButton4 = new global::System.Windows.Forms.ToolStripButton();
			this.ToolStripSeparator6 = new global::System.Windows.Forms.ToolStripSeparator();
			this.ToolStripButton1 = new global::System.Windows.Forms.ToolStripButton();
			this.SplitContainer1 = new global::System.Windows.Forms.SplitContainer();
			this.L1 = new global::NINGALINET.LV();
			this.ColumnHeader6 = new global::System.Windows.Forms.ColumnHeader();
			this.ColumnHeader8 = new global::System.Windows.Forms.ColumnHeader();
			this.MG = new global::System.Windows.Forms.ImageList(this.components);
			this.SplitContainer2 = new global::System.Windows.Forms.SplitContainer();
			this.L2 = new global::NINGALINET.LV();
			this.ColumnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.ColumnHeader3 = new global::System.Windows.Forms.ColumnHeader();
			this.ColumnHeader4 = new global::System.Windows.Forms.ColumnHeader();
			this.MG2 = new global::System.Windows.Forms.ImageList(this.components);
			this.RichTextBox1 = new global::System.Windows.Forms.RichTextBox();
			this.ContextMenuStrip3 = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.SaveToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.AToolStripMenuItem = new global::System.Windows.Forms.ToolStripSeparator();
			this.SellectAllToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripSeparator7 = new global::System.Windows.Forms.ToolStripSeparator();
			this.CutToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.CopyToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.PasteToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.pr = new global::NINGALINET.CHProgressbar();
			this.StatusStrip1.SuspendLayout();
			this.ContextMenuStrip1.SuspendLayout();
			this.ContextMenuStrip2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox1).BeginInit();
			this.Panel1.SuspendLayout();
			this.ToolStrip1.SuspendLayout();
			this.SplitContainer1.Panel1.SuspendLayout();
			this.SplitContainer1.Panel2.SuspendLayout();
			this.SplitContainer1.SuspendLayout();
			this.SplitContainer2.Panel1.SuspendLayout();
			this.SplitContainer2.Panel2.SuspendLayout();
			this.SplitContainer2.SuspendLayout();
			this.ContextMenuStrip3.SuspendLayout();
			this.SuspendLayout();
			this.StatusStrip1.BackColor = global::System.Drawing.Color.Black;
			this.StatusStrip1.Font = new global::System.Drawing.Font("Calibri", 8.25f);
			this.StatusStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.SL
			});
			global::System.Windows.Forms.Control arg_41D_0 = this.StatusStrip1;
			global::System.Drawing.Point location = new global::System.Drawing.Point(0, 340);
			arg_41D_0.Location = location;
			this.StatusStrip1.Name = "StatusStrip1";
			global::System.Windows.Forms.Control arg_447_0 = this.StatusStrip1;
			global::System.Drawing.Size size = new global::System.Drawing.Size(584, 22);
			arg_447_0.Size = size;
			this.StatusStrip1.TabIndex = 0;
			this.StatusStrip1.Text = "StatusStrip1";
			this.SL.Name = "SL";
			global::System.Windows.Forms.ToolStripItem arg_48A_0 = this.SL;
			size = new global::System.Drawing.Size(13, 17);
			arg_48A_0.Size = size;
			this.SL.Text = "..";
			this.ContextMenuStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.RefreshToolStripMenuItem
			});
			this.ContextMenuStrip1.Name = "ContextMenuStrip1";
			global::System.Windows.Forms.Control arg_4E2_0 = this.ContextMenuStrip1;
			size = new global::System.Drawing.Size(114, 26);
			arg_4E2_0.Size = size;
			this.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_509_0 = this.RefreshToolStripMenuItem;
			size = new global::System.Drawing.Size(113, 22);
			arg_509_0.Size = size;
			this.RefreshToolStripMenuItem.Text = "Refresh";
			this.ContextMenuStrip2.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.UPToolStripMenuItem,
				this.RunToolStripMenuItem,
				this.RefreshToolStripMenuItem1,
				this.ToolStripSeparator1,
				this.DeleteToolStripMenuItem,
				this.RenameToolStripMenuItem,
				this.ToolStripSeparator4,
				this.RarToolStripMenuItem,
				this.UnrarToolStripMenuItem,
				this.UploadToolStripMenuItem,
				this.DownloadToolStripMenuItem,
				this.CorruptToolStripMenuItem,
				this.StripToolStripMenuItem,
				this.EditToolStripMenuItem,
				this.HiddenToolStripMenuItem,
				this.ToolStripSeparator3,
				this.CutToolStripMenuItem,
				this.CopyToolStripMenuItem,
				this.PastToolStripMenuItem,
				this.ToolStripSeparator2,
				this.NewFolderToolStripMenuItem,
				this.ToolStripSeparator5,
				this.OpenFolderToolStripMenuItem
			});
			this.ContextMenuStrip2.Name = "ContextMenuStrip2";
			global::System.Windows.Forms.Control arg_63C_0 = this.ContextMenuStrip2;
			size = new global::System.Drawing.Size(152, 414);
			arg_63C_0.Size = size;
			this.UPToolStripMenuItem.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("UPToolStripMenuItem.Image");
			this.UPToolStripMenuItem.Name = "UPToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_681_0 = this.UPToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_681_0.Size = size;
			this.UPToolStripMenuItem.Text = "UP";
			this.UPToolStripMenuItem.Visible = false;
			this.RunToolStripMenuItem.Name = "RunToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_6C7_0 = this.RunToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_6C7_0.Size = size;
			this.RunToolStripMenuItem.Text = "Open";
			this.RefreshToolStripMenuItem1.Name = "RefreshToolStripMenuItem1";
			global::System.Windows.Forms.ToolStripItem arg_701_0 = this.RefreshToolStripMenuItem1;
			size = new global::System.Drawing.Size(151, 22);
			arg_701_0.Size = size;
			this.RefreshToolStripMenuItem1.Text = "Refresh";
			this.ToolStripSeparator1.Name = "ToolStripSeparator1";
			global::System.Windows.Forms.ToolStripItem arg_73A_0 = this.ToolStripSeparator1;
			size = new global::System.Drawing.Size(148, 6);
			arg_73A_0.Size = size;
			this.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_764_0 = this.DeleteToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_764_0.Size = size;
			this.DeleteToolStripMenuItem.Text = "Delete";
			this.RenameToolStripMenuItem.Name = "RenameToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_79E_0 = this.RenameToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_79E_0.Size = size;
			this.RenameToolStripMenuItem.Text = "Rename";
			this.ToolStripSeparator4.Name = "ToolStripSeparator4";
			global::System.Windows.Forms.ToolStripItem arg_7D7_0 = this.ToolStripSeparator4;
			size = new global::System.Drawing.Size(148, 6);
			arg_7D7_0.Size = size;
			this.RarToolStripMenuItem.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("RarToolStripMenuItem.Image");
			this.RarToolStripMenuItem.Name = "RarToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_81C_0 = this.RarToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_81C_0.Size = size;
			this.RarToolStripMenuItem.Text = "Add to archive";
			this.UnrarToolStripMenuItem.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("UnrarToolStripMenuItem.Image");
			this.UnrarToolStripMenuItem.Name = "UnrarToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_871_0 = this.UnrarToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_871_0.Size = size;
			this.UnrarToolStripMenuItem.Text = "Exract Hare";
			this.UploadToolStripMenuItem.Name = "UploadToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_8AB_0 = this.UploadToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_8AB_0.Size = size;
			this.UploadToolStripMenuItem.Text = "Upload";
			this.DownloadToolStripMenuItem.Name = "DownloadToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_8E5_0 = this.DownloadToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_8E5_0.Size = size;
			this.DownloadToolStripMenuItem.Text = "Download";
			this.CorruptToolStripMenuItem.Name = "CorruptToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_91F_0 = this.CorruptToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_91F_0.Size = size;
			this.CorruptToolStripMenuItem.Text = "File corrupt";
			this.StripToolStripMenuItem.Name = "StripToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_958_0 = this.StripToolStripMenuItem;
			size = new global::System.Drawing.Size(148, 6);
			arg_958_0.Size = size;
			this.EditToolStripMenuItem.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("EditToolStripMenuItem.Image");
			this.EditToolStripMenuItem.Name = "EditToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_99D_0 = this.EditToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_99D_0.Size = size;
			this.EditToolStripMenuItem.Text = "Edit";
			this.EditToolStripMenuItem.Visible = false;
			this.HiddenToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.ShowToolStripMenuItem,
				this.HiddenToolStripMenuItem1
			});
			this.HiddenToolStripMenuItem.Name = "HiddenToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_A0D_0 = this.HiddenToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_A0D_0.Size = size;
			this.HiddenToolStripMenuItem.Text = "Get Attribute";
			this.ShowToolStripMenuItem.Name = "ShowToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_A44_0 = this.ShowToolStripMenuItem;
			size = new global::System.Drawing.Size(114, 22);
			arg_A44_0.Size = size;
			this.ShowToolStripMenuItem.Text = "Normal";
			this.HiddenToolStripMenuItem1.Name = "HiddenToolStripMenuItem1";
			global::System.Windows.Forms.ToolStripItem arg_A7B_0 = this.HiddenToolStripMenuItem1;
			size = new global::System.Drawing.Size(114, 22);
			arg_A7B_0.Size = size;
			this.HiddenToolStripMenuItem1.Text = "Hidden";
			this.ToolStripSeparator3.Name = "ToolStripSeparator3";
			global::System.Windows.Forms.ToolStripItem arg_AB4_0 = this.ToolStripSeparator3;
			size = new global::System.Drawing.Size(148, 6);
			arg_AB4_0.Size = size;
			this.CutToolStripMenuItem.Name = "CutToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_ADE_0 = this.CutToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_ADE_0.Size = size;
			this.CutToolStripMenuItem.Text = "Cut";
			this.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_B18_0 = this.CopyToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_B18_0.Size = size;
			this.CopyToolStripMenuItem.Text = "Copy";
			this.PastToolStripMenuItem.Name = "PastToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_B52_0 = this.PastToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_B52_0.Size = size;
			this.PastToolStripMenuItem.Text = "Paste";
			this.ToolStripSeparator2.Name = "ToolStripSeparator2";
			global::System.Windows.Forms.ToolStripItem arg_B8B_0 = this.ToolStripSeparator2;
			size = new global::System.Drawing.Size(148, 6);
			arg_B8B_0.Size = size;
			this.NewFolderToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.NewFolderToolStripMenuItem1,
				this.NewEmptyFileToolStripMenuItem1
			});
			this.NewFolderToolStripMenuItem.Name = "NewFolderToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_BDF_0 = this.NewFolderToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_BDF_0.Size = size;
			this.NewFolderToolStripMenuItem.Text = "New";
			this.NewFolderToolStripMenuItem1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("NewFolderToolStripMenuItem1.Image");
			this.NewFolderToolStripMenuItem1.Name = "NewFolderToolStripMenuItem1";
			global::System.Windows.Forms.ToolStripItem arg_C34_0 = this.NewFolderToolStripMenuItem1;
			size = new global::System.Drawing.Size(156, 22);
			arg_C34_0.Size = size;
			this.NewFolderToolStripMenuItem1.Text = "New Folder";
			this.NewEmptyFileToolStripMenuItem1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("NewEmptyFileToolStripMenuItem1.Image");
			this.NewEmptyFileToolStripMenuItem1.Name = "NewEmptyFileToolStripMenuItem1";
			global::System.Windows.Forms.ToolStripItem arg_C89_0 = this.NewEmptyFileToolStripMenuItem1;
			size = new global::System.Drawing.Size(156, 22);
			arg_C89_0.Size = size;
			this.NewEmptyFileToolStripMenuItem1.Text = "New Empty File";
			this.ToolStripSeparator5.Name = "ToolStripSeparator5";
			global::System.Windows.Forms.ToolStripItem arg_CC2_0 = this.ToolStripSeparator5;
			size = new global::System.Drawing.Size(148, 6);
			arg_CC2_0.Size = size;
			this.OpenFolderToolStripMenuItem.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("OpenFolderToolStripMenuItem.Image");
			this.OpenFolderToolStripMenuItem.Name = "OpenFolderToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_D07_0 = this.OpenFolderToolStripMenuItem;
			size = new global::System.Drawing.Size(151, 22);
			arg_D07_0.Size = size;
			this.OpenFolderToolStripMenuItem.Text = "Download(s)";
			this.ColumnHeader5.Text = "Type";
			this.TextBox1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.TextBox1.BackColor = global::System.Drawing.Color.FromArgb(40, 40, 40);
			this.TextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TextBox1.Font = new global::System.Drawing.Font("Arial", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.TextBox1.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			global::System.Windows.Forms.Control arg_D99_0 = this.TextBox1;
			location = new global::System.Drawing.Point(29, 3);
			arg_D99_0.Location = location;
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.ReadOnly = true;
			global::System.Windows.Forms.Control arg_DCF_0 = this.TextBox1;
			size = new global::System.Drawing.Size(526, 20);
			arg_DCF_0.Size = size;
			this.TextBox1.TabIndex = 5;
			this.Timer1.Interval = 1000;
			this.PictureBox2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.PictureBox2.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.PictureBox2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("PictureBox2.Image");
			global::System.Windows.Forms.Control arg_E3C_0 = this.PictureBox2;
			location = new global::System.Drawing.Point(559, 3);
			arg_E3C_0.Location = location;
			this.PictureBox2.Name = "PictureBox2";
			global::System.Windows.Forms.Control arg_E63_0 = this.PictureBox2;
			size = new global::System.Drawing.Size(20, 20);
			arg_E63_0.Size = size;
			this.PictureBox2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.PictureBox2.TabIndex = 9;
			this.PictureBox2.TabStop = false;
			this.PictureBox1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.PictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("PictureBox1.Image");
			global::System.Windows.Forms.Control arg_EC8_0 = this.PictureBox1;
			location = new global::System.Drawing.Point(3, 3);
			arg_EC8_0.Location = location;
			this.PictureBox1.Name = "PictureBox1";
			global::System.Windows.Forms.Control arg_EEF_0 = this.PictureBox1;
			size = new global::System.Drawing.Size(20, 20);
			arg_EEF_0.Size = size;
			this.PictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.PictureBox1.TabIndex = 8;
			this.PictureBox1.TabStop = false;
			this.Panel1.BackColor = global::System.Drawing.Color.Black;
			this.Panel1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.Panel1.Controls.Add(this.ToolStrip1);
			this.Panel1.Controls.Add(this.PictureBox1);
			this.Panel1.Controls.Add(this.PictureBox2);
			this.Panel1.Controls.Add(this.TextBox1);
			this.Panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			global::System.Windows.Forms.Control arg_FA8_0 = this.Panel1;
			location = new global::System.Drawing.Point(0, 0);
			arg_FA8_0.Location = location;
			this.Panel1.Name = "Panel1";
			global::System.Windows.Forms.Control arg_FD2_0 = this.Panel1;
			size = new global::System.Drawing.Size(584, 53);
			arg_FD2_0.Size = size;
			this.Panel1.TabIndex = 10;
			this.ToolStrip1.BackColor = global::System.Drawing.Color.Black;
			this.ToolStrip1.Dock = global::System.Windows.Forms.DockStyle.Bottom;
			this.ToolStrip1.GripStyle = global::System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.ToolStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.ToolStripButton2,
				this.ToolStripButton3,
				this.ToolStripButton4,
				this.ToolStripSeparator6,
				this.ToolStripButton1
			});
			this.ToolStrip1.LayoutStyle = global::System.Windows.Forms.ToolStripLayoutStyle.Flow;
			global::System.Windows.Forms.Control arg_106E_0 = this.ToolStrip1;
			location = new global::System.Drawing.Point(0, 28);
			arg_106E_0.Location = location;
			this.ToolStrip1.Name = "ToolStrip1";
			this.ToolStrip1.RenderMode = global::System.Windows.Forms.ToolStripRenderMode.System;
			this.ToolStrip1.RightToLeft = global::System.Windows.Forms.RightToLeft.Yes;
			global::System.Windows.Forms.Control arg_10B0_0 = this.ToolStrip1;
			size = new global::System.Drawing.Size(582, 23);
			arg_10B0_0.Size = size;
			this.ToolStrip1.TabIndex = 13;
			this.ToolStrip1.Text = "ToolStrip1";
			this.ToolStripButton2.Checked = true;
			this.ToolStripButton2.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.ToolStripButton2.DisplayStyle = global::System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.ToolStripButton2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("ToolStripButton2.Image");
			this.ToolStripButton2.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.ToolStripButton2.Name = "ToolStripButton2";
			global::System.Windows.Forms.ToolStripItem arg_1143_0 = this.ToolStripButton2;
			size = new global::System.Drawing.Size(23, 20);
			arg_1143_0.Size = size;
			this.ToolStripButton2.Text = "View Details";
			this.ToolStripButton3.DisplayStyle = global::System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.ToolStripButton3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("ToolStripButton3.Image");
			this.ToolStripButton3.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.ToolStripButton3.Name = "ToolStripButton3";
			global::System.Windows.Forms.ToolStripItem arg_11B1_0 = this.ToolStripButton3;
			size = new global::System.Drawing.Size(23, 20);
			arg_11B1_0.Size = size;
			this.ToolStripButton3.Text = "View List";
			this.ToolStripButton4.DisplayStyle = global::System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.ToolStripButton4.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("ToolStripButton4.Image");
			this.ToolStripButton4.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.ToolStripButton4.Name = "ToolStripButton4";
			global::System.Windows.Forms.ToolStripItem arg_121F_0 = this.ToolStripButton4;
			size = new global::System.Drawing.Size(23, 20);
			arg_121F_0.Size = size;
			this.ToolStripButton4.Text = "View Title";
			this.ToolStripSeparator6.Name = "ToolStripSeparator6";
			global::System.Windows.Forms.ToolStripItem arg_1255_0 = this.ToolStripSeparator6;
			size = new global::System.Drawing.Size(6, 23);
			arg_1255_0.Size = size;
			this.ToolStripButton1.Checked = true;
			this.ToolStripButton1.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.ToolStripButton1.DisplayStyle = global::System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.ToolStripButton1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("ToolStripButton1.Image");
			this.ToolStripButton1.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.ToolStripButton1.Name = "ToolStripButton1";
			global::System.Windows.Forms.ToolStripItem arg_12CB_0 = this.ToolStripButton1;
			size = new global::System.Drawing.Size(23, 20);
			arg_12CB_0.Size = size;
			this.ToolStripButton1.Text = "Preview File Sellected";
			this.SplitContainer1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.SplitContainer1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.SplitContainer1.FixedPanel = global::System.Windows.Forms.FixedPanel.Panel1;
			global::System.Windows.Forms.Control arg_1315_0 = this.SplitContainer1;
			location = new global::System.Drawing.Point(0, 53);
			arg_1315_0.Location = location;
			this.SplitContainer1.Name = "SplitContainer1";
			this.SplitContainer1.Panel1.Controls.Add(this.L1);
			this.SplitContainer1.Panel2.Controls.Add(this.SplitContainer2);
			global::System.Windows.Forms.Control arg_1378_0 = this.SplitContainer1;
			size = new global::System.Drawing.Size(584, 272);
			arg_1378_0.Size = size;
			this.SplitContainer1.SplitterDistance = 129;
			this.SplitContainer1.SplitterWidth = 1;
			this.SplitContainer1.TabIndex = 13;
			this.L1.BackColor = global::System.Drawing.Color.Black;
			this.L1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.L1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.ColumnHeader6,
				this.ColumnHeader8
			});
			this.L1.ContextMenuStrip = this.ContextMenuStrip1;
			this.L1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.L1.Font = new global::System.Drawing.Font("Arial", 8.25f);
			this.L1.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.L1.FullRowSelect = true;
			this.L1.LargeImageList = this.MG;
			global::System.Windows.Forms.Control arg_1464_0 = this.L1;
			location = new global::System.Drawing.Point(0, 0);
			arg_1464_0.Location = location;
			this.L1.Name = "L1";
			this.L1.OwnerDraw = true;
			global::System.Windows.Forms.Control arg_149A_0 = this.L1;
			size = new global::System.Drawing.Size(127, 270);
			arg_149A_0.Size = size;
			this.L1.SmallImageList = this.MG;
			this.L1.TabIndex = 9;
			this.L1.UseCompatibleStateImageBehavior = false;
			this.L1.View = global::System.Windows.Forms.View.Details;
			this.ColumnHeader6.Text = "Name";
			this.ColumnHeader8.Text = "Type";
			this.ColumnHeader8.Width = 67;
			this.MG.ImageStream = (global::System.Windows.Forms.ImageListStreamer)componentResourceManager.GetObject("MG.ImageStream");
			this.MG.TransparentColor = global::System.Drawing.Color.Transparent;
			this.MG.Images.SetKeyName(0, "0.bmp");
			this.MG.Images.SetKeyName(1, "1.bmp");
			this.MG.Images.SetKeyName(2, "2.bmp");
			this.MG.Images.SetKeyName(3, "3.bmp");
			this.MG.Images.SetKeyName(4, "4.bmp");
			this.SplitContainer2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.SplitContainer2.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.SplitContainer2.FixedPanel = global::System.Windows.Forms.FixedPanel.Panel2;
			global::System.Windows.Forms.Control arg_15CF_0 = this.SplitContainer2;
			location = new global::System.Drawing.Point(0, 0);
			arg_15CF_0.Location = location;
			this.SplitContainer2.Name = "SplitContainer2";
			this.SplitContainer2.Panel1.Controls.Add(this.L2);
			this.SplitContainer2.Panel2.Controls.Add(this.RichTextBox1);
			global::System.Windows.Forms.Control arg_1632_0 = this.SplitContainer2;
			size = new global::System.Drawing.Size(454, 272);
			arg_1632_0.Size = size;
			this.SplitContainer2.SplitterDistance = 341;
			this.SplitContainer2.SplitterWidth = 1;
			this.SplitContainer2.TabIndex = 10;
			this.L2.BackColor = global::System.Drawing.Color.Black;
			this.L2.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.L2.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.ColumnHeader2,
				this.ColumnHeader3,
				this.ColumnHeader4
			});
			this.L2.ContextMenuStrip = this.ContextMenuStrip2;
			this.L2.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.L2.Font = new global::System.Drawing.Font("Arial", 8f);
			this.L2.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.L2.FullRowSelect = true;
			this.L2.LargeImageList = this.MG2;
			global::System.Windows.Forms.Control arg_1728_0 = this.L2;
			location = new global::System.Drawing.Point(0, 0);
			arg_1728_0.Location = location;
			this.L2.Name = "L2";
			this.L2.OwnerDraw = true;
			global::System.Windows.Forms.Control arg_1761_0 = this.L2;
			size = new global::System.Drawing.Size(339, 270);
			arg_1761_0.Size = size;
			this.L2.SmallImageList = this.MG2;
			this.L2.TabIndex = 7;
			this.L2.UseCompatibleStateImageBehavior = false;
			this.L2.View = global::System.Windows.Forms.View.Details;
			this.ColumnHeader2.Text = "Name";
			this.ColumnHeader2.Width = 175;
			this.ColumnHeader3.Text = "Size";
			this.ColumnHeader3.Width = 66;
			this.ColumnHeader4.Text = "Type";
			this.ColumnHeader4.Width = 197;
			this.MG2.ColorDepth = global::System.Windows.Forms.ColorDepth.Depth32Bit;
			global::System.Windows.Forms.ImageList arg_1817_0 = this.MG2;
			size = new global::System.Drawing.Size(18, 18);
			arg_1817_0.ImageSize = size;
			this.MG2.TransparentColor = global::System.Drawing.Color.Transparent;
			this.RichTextBox1.BackColor = global::System.Drawing.Color.FromArgb(40, 40, 40);
			this.RichTextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.RichTextBox1.ContextMenuStrip = this.ContextMenuStrip3;
			this.RichTextBox1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.RichTextBox1.Font = new global::System.Drawing.Font("Arial", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.RichTextBox1.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			global::System.Windows.Forms.Control arg_18A8_0 = this.RichTextBox1;
			location = new global::System.Drawing.Point(0, 0);
			arg_18A8_0.Location = location;
			this.RichTextBox1.Name = "RichTextBox1";
			global::System.Windows.Forms.Control arg_18D2_0 = this.RichTextBox1;
			size = new global::System.Drawing.Size(110, 270);
			arg_18D2_0.Size = size;
			this.RichTextBox1.TabIndex = 8;
			this.RichTextBox1.Text = "Sellect a file to preview.";
			this.ContextMenuStrip3.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.SaveToolStripMenuItem,
				this.AToolStripMenuItem,
				this.SellectAllToolStripMenuItem,
				this.ToolStripSeparator7,
				this.CutToolStripMenuItem1,
				this.CopyToolStripMenuItem1,
				this.PasteToolStripMenuItem
			});
			this.ContextMenuStrip3.Name = "ContextMenuStrip1";
			global::System.Windows.Forms.Control arg_196C_0 = this.ContextMenuStrip3;
			size = new global::System.Drawing.Size(126, 126);
			arg_196C_0.Size = size;
			this.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_1993_0 = this.SaveToolStripMenuItem;
			size = new global::System.Drawing.Size(125, 22);
			arg_1993_0.Size = size;
			this.SaveToolStripMenuItem.Text = "Save";
			this.AToolStripMenuItem.Name = "AToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_19C9_0 = this.AToolStripMenuItem;
			size = new global::System.Drawing.Size(122, 6);
			arg_19C9_0.Size = size;
			this.SellectAllToolStripMenuItem.Name = "SellectAllToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_19F0_0 = this.SellectAllToolStripMenuItem;
			size = new global::System.Drawing.Size(125, 22);
			arg_19F0_0.Size = size;
			this.SellectAllToolStripMenuItem.Text = "Sellect All";
			this.ToolStripSeparator7.Name = "ToolStripSeparator7";
			global::System.Windows.Forms.ToolStripItem arg_1A26_0 = this.ToolStripSeparator7;
			size = new global::System.Drawing.Size(122, 6);
			arg_1A26_0.Size = size;
			this.CutToolStripMenuItem1.Name = "CutToolStripMenuItem1";
			global::System.Windows.Forms.ToolStripItem arg_1A4D_0 = this.CutToolStripMenuItem1;
			size = new global::System.Drawing.Size(125, 22);
			arg_1A4D_0.Size = size;
			this.CutToolStripMenuItem1.Text = "Cut";
			this.CopyToolStripMenuItem1.Name = "CopyToolStripMenuItem1";
			global::System.Windows.Forms.ToolStripItem arg_1A84_0 = this.CopyToolStripMenuItem1;
			size = new global::System.Drawing.Size(125, 22);
			arg_1A84_0.Size = size;
			this.CopyToolStripMenuItem1.Text = "Copy";
			this.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem";
			global::System.Windows.Forms.ToolStripItem arg_1ABB_0 = this.PasteToolStripMenuItem;
			size = new global::System.Drawing.Size(125, 22);
			arg_1ABB_0.Size = size;
			this.PasteToolStripMenuItem.Text = "Paste";
			this.pr.BackColor = global::System.Drawing.Color.Transparent;
			this.pr.Colors = new global::NINGALINET.Bloom[0];
			this.pr.Customization = global::NINGALINET.My.Resources.Resources.notf;
			this.pr.Dock = global::System.Windows.Forms.DockStyle.Bottom;
			this.pr.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.pr.Image = null;
			global::System.Windows.Forms.Control arg_1B47_0 = this.pr;
			location = new global::System.Drawing.Point(0, 325);
			arg_1B47_0.Location = location;
			this.pr.Maximum = 100;
			this.pr.Name = "pr";
			this.pr.NoRounding = false;
			global::System.Windows.Forms.Control arg_1B8A_0 = this.pr;
			size = new global::System.Drawing.Size(584, 15);
			arg_1B8A_0.Size = size;
			this.pr.TabIndex = 12;
			this.pr.Text = "ChProgressbar1";
			this.pr.Transparent = true;
			this.pr.Value = 0;
			global::System.Drawing.SizeF autoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Black;
			size = new global::System.Drawing.Size(584, 362);
			this.ClientSize = size;
			this.Controls.Add(this.SplitContainer1);
			this.Controls.Add(this.pr);
			this.Controls.Add(this.Panel1);
			this.Controls.Add(this.StatusStrip1);
			this.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.Name = "FrmFilemanager";
			this.ShowIcon = false;
			this.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FM";
			this.StatusStrip1.ResumeLayout(false);
			this.StatusStrip1.PerformLayout();
			this.ContextMenuStrip1.ResumeLayout(false);
			this.ContextMenuStrip2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox1).EndInit();
			this.Panel1.ResumeLayout(false);
			this.Panel1.PerformLayout();
			this.ToolStrip1.ResumeLayout(false);
			this.ToolStrip1.PerformLayout();
			this.SplitContainer1.Panel1.ResumeLayout(false);
			this.SplitContainer1.Panel2.ResumeLayout(false);
			this.SplitContainer1.ResumeLayout(false);
			this.SplitContainer2.Panel1.ResumeLayout(false);
			this.SplitContainer2.Panel2.ResumeLayout(false);
			this.SplitContainer2.ResumeLayout(false);
			this.ContextMenuStrip3.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x040001C1 RID: 449
		private global::System.ComponentModel.IContainer components;
	}
}
