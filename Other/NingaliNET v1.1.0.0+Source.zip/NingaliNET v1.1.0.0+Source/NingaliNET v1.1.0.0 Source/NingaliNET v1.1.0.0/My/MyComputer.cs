﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.VisualBasic.Devices;

namespace NINGALINET.My
{
	// Token: 0x02000004 RID: 4
	[EditorBrowsable(EditorBrowsableState.Never), GeneratedCode("MyTemplate", "8.0.0.0")]
	internal class MyComputer : Computer
	{
		// Token: 0x06000006 RID: 6 RVA: 0x00002285 File Offset: 0x00000485
		[EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden]
		public MyComputer()
		{
			Class2.zP7eVJHzSiX6G();
			base..ctor();
		}
	}
}
