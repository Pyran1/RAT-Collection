===============================

Blizzard-RAT from iJuan

===============================


I recommend to run this on a Windows 7 and up, in a virtualbox.
This tool will have detection of course it will, it has function that maybe similar 
to a trojan, but it doesn't have any malware attached to it or will not harm your pc.

Our facebook fan page: https://www.facebook.com/pages/Iron-Juan/536185189754630?ref=hl


===============================

This is a lite version only! some features were locked or hidden.
Delete Ratlv.dat and config.ini if random error appear on the builder.

FAQ: http://www.blizzard-rat.com/FAQ.php
