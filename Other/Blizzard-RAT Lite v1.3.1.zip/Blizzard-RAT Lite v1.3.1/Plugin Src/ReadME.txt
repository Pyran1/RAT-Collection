Put the dll to the "Plugins" folder, same location where the Blizzard-RAT is.
If you dont have a plugins folder just create one.