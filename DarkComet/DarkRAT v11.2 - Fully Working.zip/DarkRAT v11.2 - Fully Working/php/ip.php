<?php
$ip = getenv("REMOTE_ADDR");
echo $ip;
?>