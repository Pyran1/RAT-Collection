<?php
unlink('uploads/image.jpg');
?>