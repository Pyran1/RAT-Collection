<?php
$file = $_GET['file'];
unlink('uploads/'.$file);
?>