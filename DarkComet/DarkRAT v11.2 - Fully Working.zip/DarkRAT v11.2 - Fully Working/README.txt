You've agreed with the Terms of use.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Created by goranpilkic
Do not distribute program or source without author permission!
You are not allowed to edit any part of program without autor permission!
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
You've automatic accepted the terms of use.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DarkRAT is PHP based RAT (Remote Administration Tool) which doesnt require port forward.
You only need to have hosting with only (!) 4MB space! You can use it with some free hostings.
No - http://000webhost.com isn't supported. DarkRAT will offer you same functions like and other
TCP/UDP RAT have. You can test it on localhost. It's easy to use.
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Thanks to :

-Miharbi-DoNo
-Black-Blood
-DarkSel
-Butterfly/Methanity
-DarkCoder

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
If you didnt buyed this program from 'goranpilkic' or 'Butterfly' your program will be illegal.
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Powered sites :

-http://boardforum.org
-http://hackforums.net
-http://leetcoders.org

#################################################### 
###########                             ############    
########### How do i install DarkRAT?   ############ 
###########                             ############ 
###########                             ############ 
#################################################### 

1. Upload the php folder to your host, make sure chmod is set to 777 - But if you get a INTERNAL SERVER ERROR change the chmod back to 775.
2. Now open DarkRAT and enter your website url example: http://yourwebsitehere.com/php/
3. And connect, now you open the builder and enter your URL once again.
4. Choose your functions and test it(on yourself or on a virtual machine)
5. Enjoy
