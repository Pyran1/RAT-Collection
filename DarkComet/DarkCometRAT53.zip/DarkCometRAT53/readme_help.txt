    ___           _      ___                     _       __    _   _____ 
   /   \__ _ _ __| | __ / __\___  _ __ ___   ___| |_    /__\  /_\ /__   \
  / /\ / _` | '__| |/ // /  / _ \| '_ ` _ \ / _ \ __|  / \// //_\\  / /\/
 / /_// (_| | |  |   </ /__| (_) | | | | | |  __/ |_  / _  \/  _  \/ /   
/___,' \__,_|_|  |_|\_\____/\___/|_| |_| |_|\___|\__| \/ \_/\_/ \_/\/   

 ___        ___           _    ___         _         ___     
| _ )_  _  |   \ __ _ _ _| |__/ __|___  __| |___ _ _/ __| __ 
| _ \ || | | |) / _` | '_| / / (__/ _ \/ _` / -_) '_\__ \/ _|
|___/\_, | |___/\__,_|_| |_\_\\___\___/\__,_\___|_| |___/\__|
     |__/   

Downloaded from http://www.darkcomet-rat.com/

Coded and Directed by DarkCoderSc (Jean-Pierre LESUEUR)
---

Feel free to join my Facebook page, Twitter and Google+ Account to get the last news about DarkComet RAT development and related programs.

Be sure to read carefully the website help and the help inside DarkComet RAT program.

99% of issue are ONLY because you didn't read the help so do it, it will take few minuts of your life, but in final you will don't
need to search everywhere for a solution so you will earn more time than you lost.

Here are the most common problems :

- Can't open DarkComet.exe and related Applications from the package.
  ANSWER: You must disable your Antivirus to use a such tools, don't worry DarkComet RAT detection is a false positive, it is a safe exectuable
          But antivirus companies must detect these tools because it is to oftenly used by Hackers.

- I disabled all my Antivirus and related resident shield however after few minuts the program shutdown by itself.
  ANSWER: This is the symptom of Windows Defender, you must disable it (google it), it is in Windows Control Center > SECURITY > Windows Defender.

- I can't see any users in the list. 
  ANSWER: Be sure your port are successfully forwarded using http://canyouseeme.org/ ; until this website notify your ports are correctly
          Forwarded, DarkComet won't work.
          Also disable any kind of Firewalls even Microsoft embedded one.

Feel free to use DarkComet RAT under a virtual environment as you need to disable all security in your machine, then it is more safe.
Notice you must setup your VM in bridge or physical interface instead of NAT in network settings.

If you need a personal help, subscribe to the VIP Lounge, all informations are located here : http://www.darkcomet-rat.com/lounge.dc

darkcodersc@gmail.com at your service ;-)