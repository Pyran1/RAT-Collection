Features of the current version 2.9 : -
- Coder By U A C O D E R
- Easy encryption server output 
- Constancy in Contact
- SERVER Size: 96 KB
- Victims will not lose anymore
- Spread function was developed stronger