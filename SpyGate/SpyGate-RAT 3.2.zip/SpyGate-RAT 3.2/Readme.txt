present to you a new light version of the program (SpyGate-RAT v 3.2)

Version features:

1. The re-application from scratch programming
2. a simple amendment to the Alsuchit to make it lighter than the previous
3. correct some of the mistakes and correct When you copy the value in the Registry
4. Amendment in the filming of the screen faster than the previous version
5. pull password stronger than the previous addition is brought any update when you save your password
6. feature [Transfer] in, file manager to see transport and lifting full control case
7. new additions in Albildir
8. became less the size of the server [83 KB] and became an encrypted most of the protections of 6/34
9. many changes in this version